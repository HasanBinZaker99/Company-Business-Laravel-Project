<!DOCTYPE html>
<html>

<head>
    <title>KAIZEN IT LTD</title>
</head>

<body>

    <h1>Hi, {{ $user->name }}</h1>
    <p>{{ $user->email }}</p>

    <p>Thank you</p>
</body>

</html>